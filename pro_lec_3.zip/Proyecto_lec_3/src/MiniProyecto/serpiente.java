package MiniProyecto;

public class serpiente implements animal {
	
	private chip chip;
	public enum colores {VERDE, AMARILLA, BLANCA};
	private colores color;
	private int edad;
	
	public serpiente(chip chip, colores color,int edad) {
		this.chip = chip;
		this.color = color;
		this.edad=edad;
	}
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("La serpiente esta comiendo");
	}

	@Override
	public void cominucate() {
		// TODO Auto-generated method stub
		System.out.println("sshh-sshh-sshh");
	}

	@Override
	public void duerme() {
		// TODO Auto-generated method stub
		System.out.println("zZz ZzZ zZz");
	}

	@Override
	public String dimeDueño() {
		return "El dueño es " + this.getChip().getPropietario();
	}
	

	public chip getChip() {
		return chip;
	}

	public void setChip(chip chip) {
		this.chip = chip;
	}

	public colores getColor() {
		return color;
	}

	public void setColor(colores color) {
		this.color = color;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

}
