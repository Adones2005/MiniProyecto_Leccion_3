package MiniProyecto;

public class perro implements animal{

	private chip chip;
	public enum razas {KOKER, GALGO, PITBULL};
	private razas raza;
	private int edad;
	
	public chip getChip() {
		return chip;
	}



	public void setChip(chip chip) {
		this.chip = chip;
	}



	public razas getRaza() {
		return raza;
	}



	public void setRaza(razas raza) {
		this.raza = raza;
	}



	public int getEdad() {
		return edad;
	}



	public void setEdad(int edad) {
		this.edad = edad;
	}



	public perro(chip chip, razas raza, int edad) {
		this.chip = chip;
		this.raza = raza;
		this.edad=edad;
	}
	
	
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("El perro esta comiendo");
	}

	@Override
	public void cominucate() {
		// TODO Auto-generated method stub
		System.out.println("guau-guau-guau");
	}

	@Override
	public void duerme() {
		// TODO Auto-generated method stub
		System.out.println("zZz ZzZ zZz");
	}



	@Override
	public String dimeDueño() {
		// TODO Auto-generated method stub
		return "El dueño es " + this.getChip().getPropietario();
	}
	
}
