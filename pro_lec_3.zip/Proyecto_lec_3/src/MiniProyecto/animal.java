package MiniProyecto;

public interface animal {
	
	public void comer();
	
	public void cominucate();
	
	public void duerme();
	
	public String dimeDueño();
	
}
