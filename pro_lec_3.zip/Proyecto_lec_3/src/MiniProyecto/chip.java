package MiniProyecto;

public class chip {
	private int id;
	private String propietario;
	public static int contador = 0;
	
		public chip(String propietario){
			contador++;
			this.id = contador;
			this.propietario=propietario;
		}
	
		public void localizar() {
			System.out.println("El animal se encuentra en X");
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getPropietario() {
			return propietario;
		}

		public void setPropietario(String propietario) {
			this.propietario = propietario;
		}
}
