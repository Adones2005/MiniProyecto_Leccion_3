package MiniProyecto;

public class gato implements animal {

	private chip chip;
	private int edad;
	
	public gato(chip chip, int edad) {
		this.chip = chip;
		this.edad = edad;
	}
	
	
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("El gato esta comiendo");
	}

	@Override
	public void cominucate() {
		// TODO Auto-generated method stub
		System.out.println("miau-miau-miau");
	}

	@Override
	public void duerme() {
		// TODO Auto-generated method stub
		System.out.println("zZz ZzZ zZz");
	}



	public chip getChip() {
		return chip;
	}



	public void setChip(chip chip) {
		this.chip = chip;
	}



	public int getEdad() {
		return edad;
	}



	public void setEdad(int edad) {
		this.edad = edad;
	}



	@Override
	public String dimeDueño() {
		// TODO Auto-generated method stub
		return "El dueño es " + this.getChip().getPropietario();
	}

}
