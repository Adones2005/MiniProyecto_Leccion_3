package MiniProyecto;

import MiniProyecto.perro.razas;
import MiniProyecto.serpiente.colores;

public class usoAnimal {
	public static void main(String[] args) {
			
			chip chip1 = new chip("Manolo");
			chip chip2 = new chip("Paco");
			chip chip3 = new chip("Carmen");
			animal pelusa = new gato(chip1, 3);
			animal tobi = new perro(chip2,razas.PITBULL, 1);
			animal snake = new serpiente(chip3,colores.VERDE, 6);
		
			System.out.println("------------- PRUEBA GATO ----------------\n");
			
			pelusa.comer();
			pelusa.cominucate();
			System.out.println(pelusa.dimeDueño());
			pelusa.duerme();
			
			
			
			System.out.println("\n\n------------- PRUEBA PERRO ----------------\n");
			

			tobi.comer();
			tobi.cominucate();
			System.out.println(tobi.dimeDueño());
			tobi.duerme();
			
			
			
			
			System.out.println("\n\n------------- PRUEBA SERPIENTE ----------------\n");
			

			snake.comer();
			snake.cominucate();
			System.out.println(snake.dimeDueño());
			snake.duerme();
	}
}
